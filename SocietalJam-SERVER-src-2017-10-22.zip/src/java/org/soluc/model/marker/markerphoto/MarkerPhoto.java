package org.soluc.model.marker.markerphoto;

/**
 *
 * @author JSQLGen
 */
public final class MarkerPhoto {

    /**
     * Atributos
     */
    private Integer id;
    private java.util.Date when;
    private Integer member;
    private byte[] photo;

    /**
     * Construtor
     */
    public MarkerPhoto() {
        id = null;
        when = new java.util.Date();
        member = 0;
        photo = new byte[0];
    }

    /**
     * Metodos
     */

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id Id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @param id - String id to set
     */
    public void setId(String id) {
        this.id = (id.equals("null") || id.isEmpty()) ? null : Integer.parseInt(id);
    }

    /**
     * @return When
     */
    public java.util.Date getWhen() {
        return when;
    }

    /**
     * @param pattern Formato de When. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @return When Formatado
     */
    public String getWhenF(String pattern) {
        return new java.text.SimpleDateFormat(pattern).format(when);
    }

    /**
     * @param when When to set
     */
    public void setWhen(java.util.Date when) {
        this.when = when;
    }

    /**
     * @param pattern Formato de When. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @param when - String When to set
     */
    public void setWhenF(String pattern, String when) {
        this.when = new java.text.SimpleDateFormat(pattern).parse(when, new java.text.ParsePosition(0));
    }

    /**
     * @return member
     */
    public Integer getMember() {
        return member;
    }

    /**
     * @param member Member to set
     */
    public void setMember(Integer member) {
        this.member = member;
    }

    /**
     * @param member - String member to set
     */
    public void setMember(String member) {
        this.member = Integer.parseInt(member);
    }

    /**
     * @return Photo
     */
    public byte[] getPhoto() {
        return photo;
    }

    /**
     * @param photo Photo to set
     */
    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }

    /**
     * @param photo the photo to set
     * @param format PNG | JPG | GIF
     */
    public void setPhoto(java.awt.Image photo, String format) {
        setPhoto(photo, format, photo.getWidth(null));
    }

    /**
     * @param photo the photo to set
     * @param format PNG | JPG | GIF
     * @param width Image width
     */
    public void setPhoto(java.awt.Image photo, String format, int width) {
        if (photo != null) {
            try {
                width = Math.abs(width);
                if (width == 0) {
                    width = photo.getWidth(null);
                }
                int height = (width * photo.getHeight(null)) / photo.getWidth(null);
                java.awt.image.BufferedImage bf = new java.awt.image.BufferedImage(width, height, java.awt.image.BufferedImage.TYPE_INT_ARGB);
                bf.createGraphics().drawImage(photo, 0, 0, width, height, null);
                java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
                javax.imageio.ImageIO.write(bf, format, output);
                setPhoto(output.toByteArray());
            } catch (IllegalArgumentException | java.io.IOException e) {
                e.printStackTrace();
                setPhoto(new byte[0]);
            }
        }
    }

    /**
     * @return Photo to Image
     */
    public java.awt.Image getPhotoToImage() {
        try {
            return javax.imageio.ImageIO.read(new java.io.ByteArrayInputStream(this.photo));
        } catch (java.io.IOException e) {
            e.printStackTrace();
            return new javax.swing.ImageIcon().getImage();
        }
    }

    /**
     * @return Photo to ImageIcon
     */
    public javax.swing.ImageIcon getPhotoToImageIcon() {
        if (this.photo.length > 0) {
            return new javax.swing.ImageIcon(getPhotoToImage());
        } else {
            return new javax.swing.ImageIcon();
        }
    }

    /**
     * Salva Photo em arquivo
     *
     * @param path - path file
     * @param format - JPG,PNG,GIF
     * @throws java.io.IOException
     */
    public void savePhoto(String path, String format) throws java.io.IOException {
        java.awt.Image photoSave = getPhotoToImage();
        java.awt.image.BufferedImage bf = new java.awt.image.BufferedImage(photoSave.getWidth(null), photoSave.getHeight(null), java.awt.image.BufferedImage.TYPE_INT_ARGB);
        bf.createGraphics().drawImage(photoSave, null, null);
        java.io.File file = new java.io.File(path);
        javax.imageio.ImageIO.write(bf, format, file);
    }

    /**
     * Carrega arquivo de imagem para Photo
     *
     * @param path - path file
     * @param format
     */
    public void loadPhoto(String path, String format) {
        setPhoto(new javax.swing.ImageIcon(path).getImage(), format);
    }

}
