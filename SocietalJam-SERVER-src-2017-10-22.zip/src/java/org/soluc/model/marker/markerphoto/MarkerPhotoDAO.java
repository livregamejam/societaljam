package org.soluc.model.marker.markerphoto;

/**
 * Class MarkerPhotoDAO responsável pela 
 * leitura/escrita de objetos MarkerPhoto no BD
 *
 * @author JSQLGen
 */
public final class MarkerPhotoDAO extends dbaccess.DAO {

    //*****************************************
    //CREATE TABLE
    //*****************************************

    /** createTable - Cria a tabela MarkerPhoto no BD
     * @param connection Conexão com BD
     * @throws java.sql.SQLException
     */
    public static void createTable(java.sql.Connection connection) throws java.sql.SQLException {
        String sql = "CREATE TABLE MarkerPhoto ("
                   + "markerOwner INT NOT NULL,"
                   + "id INT NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH 1, INCREMENT BY 1),"
                   + "when DATE NOT NULL,"
                   + "member INT NOT NULL,"
                   + "photo BLOB NOT NULL,"
                   + "CONSTRAINT PK_MarkerPhoto PRIMARY KEY (id),"
                   + "CONSTRAINT FKC_MarkerPhoto_MarkerOwner FOREIGN KEY (markerOwner) REFERENCES Marker ON DELETE CASCADE"
                   + ")";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.executeUpdate();
        statement.close();
    }

    //*****************************************
    //UPDATE
    //*****************************************

    /** obj2stmt - Transfere o Objeto para o PreparedStatement.
     * @param connection Conexão com BD
     * @param markerPhotoSave MarkerPhoto a ser armazenado
     * @param statement PreparedStatement contendo SQL
     * @throws java.sql.SQLException
     * @param markerOwner Marker owner
     */
    private static void obj2stmt(MarkerPhoto markerPhotoSave, org.soluc.model.marker.Marker markerOwner, java.sql.PreparedStatement statement) throws java.sql.SQLException {
        statement.setInt(1, markerOwner.getId());
        statement.setDate(2, new java.sql.Date(markerPhotoSave.getWhen().getTime()));
        statement.setInt(3, markerPhotoSave.getMember());
        statement.setBlob(4, new javax.sql.rowset.serial.SerialBlob(markerPhotoSave.getPhoto()));
    }

    /** insert - Este método insere no BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param markerPhotoInsert MarkerPhoto a ser inserido
     * @param markerOwner Marker owner
     * @throws java.sql.SQLException
     */
    public static void insert(java.sql.Connection connection, MarkerPhoto markerPhotoInsert, org.soluc.model.marker.Marker markerOwner) throws java.sql.SQLException {
        String sql = "INSERT INTO MarkerPhoto (markerOwner,when,member,photo) "
                   + "VALUES (?,?,?,?)";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        obj2stmt(markerPhotoInsert, markerOwner, statement);
        statement.executeUpdate();
        statement.close();
        sql = "SELECT IDENTITY_VAL_LOCAL() FROM MarkerPhoto";
        statement = connection.prepareStatement(sql);
        java.sql.ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            markerPhotoInsert.setId(resultSet.getInt(1));
        }
        statement.close();
    }

    /** update - Este método atualiza no BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param markerPhotoUpdate MarkerPhoto a ser atualizado
     * @param markerOwner Marker owner
     * @throws java.sql.SQLException
     */
    public static void update(java.sql.Connection connection, MarkerPhoto markerPhotoUpdate, org.soluc.model.marker.Marker markerOwner) throws java.sql.SQLException {
        String sql = "UPDATE MarkerPhoto SET "
                   + "markerOwner = ?,"
                   + "when = ?,"
                   + "member = ?,"
                   + "photo = ? "
                   + "WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        obj2stmt(markerPhotoUpdate, markerOwner, statement);
        statement.setInt(5, markerPhotoUpdate.getId());
        statement.executeUpdate();
        statement.close();
    }

    /** delete - Este método apaga do BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param markerPhotoDelete MarkerPhoto a ser apagado
     * @throws java.sql.SQLException
     */
    public static void delete(java.sql.Connection connection, MarkerPhoto markerPhotoDelete) throws java.sql.SQLException {
        String sql = "DELETE FROM MarkerPhoto WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, markerPhotoDelete.getId());
        statement.executeUpdate();
        statement.close();
    }

    //*****************************************
    //QUERY private
    //*****************************************

    /**
     * rs2obj - Transfere do ResultSet da Query SQL para um novo objeto
     * @param connection
     * @param resultSet to parse
     * @return novo objeto
     * @throws java.sql.SQLException 
     */
    private static MarkerPhoto rs2obj(java.sql.Connection connection, java.sql.ResultSet resultSet) throws java.sql.SQLException {
        MarkerPhoto markerPhotoLoad = new MarkerPhoto();
        markerPhotoLoad.setId(resultSet.getInt("id"));
        markerPhotoLoad.setWhen(resultSet.getDate("when"));
        markerPhotoLoad.setMember(resultSet.getInt("member"));
        markerPhotoLoad.setPhoto(resultSet.getBytes("photo"));
        return markerPhotoLoad;
    }

    /** load - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param condition Condição WHERE
     * @return objeto MarkerPhoto || null caso não encontrar
     * @throws java.sql.SQLException
     */
    private static MarkerPhoto load(java.sql.Connection connection, String condition) throws java.sql.SQLException {
        if(!condition.isEmpty()){
            String sql = "SELECT id,when,member,photo "
                       + "FROM MarkerPhoto "
                       + "WHERE "+condition;
            java.sql.PreparedStatement statement = connection.prepareStatement(sql);
            java.sql.ResultSet resultSet = statement.executeQuery();
            MarkerPhoto markerPhotoLoad;
            if (resultSet.next()) {
                markerPhotoLoad = rs2obj(connection, resultSet);
            } else {
                markerPhotoLoad = null;
            }
            statement.close();
            return markerPhotoLoad;
        } else {
            return null;
        }
    }

    /** loadList - Carrega lista de objetos MarkerPhoto
     * @param connection Conexão com BD
     * @param condition Condição WHERE
     * @return List contendo a tabela
     */
    private static java.util.List<MarkerPhoto> loadList(java.sql.Connection connection, String condition) {
        java.util.List<MarkerPhoto> list = new java.util.ArrayList<MarkerPhoto>();
        try {
            String sql = "SELECT id,when,member,photo "
                       + "FROM MarkerPhoto "
                       + (condition.isEmpty()?"":"WHERE "+condition);
            java.sql.PreparedStatement statement = connection.prepareStatement(sql);
            java.sql.ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                MarkerPhoto markerPhotoLoad = rs2obj(connection, resultSet);
                list.add(markerPhotoLoad);
            }
            statement.close();
        } catch (java.sql.SQLException sqlex) {
            System.out.println("Falha na leitura do banco de dados !\n"+sqlex.getMessage());
        }
        return list;
    }

    /** loadView - Carrega visão de atributos de objetos MarkerPhoto
     * @param connection Conexão com BD
     * @param attributesList Atributos listados
     * @param condition condição WHERE
     * @param order Ordem da lista
     * @return lista de atributo
     */
    private static java.util.List loadView(java.sql.Connection connection, String attributesList, String condition, String order) {
        String sql = "SELECT " + attributesList + " "
                   + "FROM MarkerPhoto "
                   + (condition.isEmpty() ? "" : "WHERE " + condition)
                   + (order.isEmpty() ? "" : "ORDER BY " + order);
        return execQueryF(connection, sql);
    }

    //*****************************************
    //QUERY public
    //*****************************************

    //*****************************************
    //LOAD Object BY
    //*****************************************

    /** loadById - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de MarkerPhoto
     * @return objeto MarkerPhoto || null caso não encontrar
     * @throws java.sql.SQLException
     */
    public static MarkerPhoto loadById(java.sql.Connection connection, Integer id) throws java.sql.SQLException {
        return load(connection, "id = "+id);
    }

    //*****************************************
    //EXISTS Object BY
    //*****************************************

    /** existsById - Este método verifica a existência de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de MarkerPhoto
     * @return true caso exista || false caso não exista
     */
    public static Boolean existsById(java.sql.Connection connection, Integer id) {
        java.util.List<MarkerPhoto> l = loadList(connection, "id="+id);
        return !l.isEmpty();
    }

    //*****************************************
    //LOAD Attribute List
    //*****************************************

    /** loadIdList - Carrega lista de id de objetos MarkerPhoto
     * @param connection Conexão com BD
     * @return List contendo Id
     */
    public static java.util.List<String> loadIdList(java.sql.Connection connection) {
        return loadView(connection, "id", "", "id");
    }

    //*****************************************
    //LOAD Object List
    //*****************************************

    /** loadList - Retorna Lista de objetos MarkerPhoto por Marker
     * @param connection Conexão com BD
     * @param markerOwner Marker
     * @return List contendo os objetos
     */
    public static java.util.List<MarkerPhoto> loadList(java.sql.Connection connection, org.soluc.model.marker.Marker markerOwner) {
        return loadList(connection, "markerOwner = " + markerOwner.getId());
    }

    //*****************************************
    //LOAD Object View
    //*****************************************

}
