package org.soluc.model.marker.markercomment;
/**
 *
 * @author JSQLGen
 */
public final class MarkerComment {


    /** Atributos */
    private Integer id;
    private Integer member;
    private java.util.Date when;
    private String comment;

    /** Construtor */
    public MarkerComment() {
        id = null;
        member = 0;
        when = new java.util.Date();
        comment = "";
    }
    /** Metodos */

    /**
     * @return id
     */
    public Integer getId() { return id; }
    /**
     * @param id Id to set
     */
    public void setId(Integer id) { this.id = id; }
    /**
     * @param id - String id to set
     */
    public void setId(String id) { this.id = (id.equals("null") || id.isEmpty())?null:Integer.parseInt(id); }

    /**
     * @return member
     */
    public Integer getMember() { return member; }
    /**
     * @param member Member to set
     */
    public void setMember(Integer member) { this.member = member; }
    /**
     * @param member - String member to set
     */
    public void setMember(String member) { this.member = Integer.parseInt(member); }

    /**
     * @return When
     */
    public java.util.Date getWhen() { return when; }
    /**
     * @param pattern Formato de When. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @return When Formatado
     */
    public String getWhenF(String pattern) { return new java.text.SimpleDateFormat(pattern).format(when); }
    /**
     * @param when When to set
     */
    public void setWhen(java.util.Date when) { this.when = when; }
    /**
     * @param pattern Formato de When. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @param when - String When to set
     */
    public void setWhenF(String pattern, String when) { this.when = new java.text.SimpleDateFormat(pattern).parse(when, new java.text.ParsePosition(0)); }

    /**
     * @return comment
     */
    public String getComment() { return comment; }
    /**
     * @param comment Comment to set
     */
    public void setComment(String comment) { this.comment = (comment.length()>200?comment.substring(0,200):comment).replace('\'','`'); }
}
