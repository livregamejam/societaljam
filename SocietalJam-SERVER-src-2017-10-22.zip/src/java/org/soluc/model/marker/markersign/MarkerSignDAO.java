package org.soluc.model.marker.markersign;

/**
 * Class MarkerSignDAO responsável pela 
 * leitura/escrita de objetos MarkerSign no BD
 *
 * @author JSQLGen
 */
public final class MarkerSignDAO extends dbaccess.DAO {

    //*****************************************
    //CREATE TABLE
    //*****************************************

    /** createTable - Cria a tabela MarkerSign no BD
     * @param connection Conexão com BD
     * @throws java.sql.SQLException
     */
    public static void createTable(java.sql.Connection connection) throws java.sql.SQLException {
        String sql = "CREATE TABLE MarkerSign ("
                   + "markerOwner INT NOT NULL,"
                   + "id INT NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH 1, INCREMENT BY 1),"
                   + "member INT NOT NULL,"
                   + "when DATE NOT NULL,"
                   + "type INT NOT NULL,"
                   + "CONSTRAINT PK_MarkerSign PRIMARY KEY (id),"
                   + "CONSTRAINT FKC_MarkerSign_MarkerOwner FOREIGN KEY (markerOwner) REFERENCES Marker ON DELETE CASCADE"
                   + ")";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.executeUpdate();
        statement.close();
    }

    //*****************************************
    //UPDATE
    //*****************************************

    /** obj2stmt - Transfere o Objeto para o PreparedStatement.
     * @param connection Conexão com BD
     * @param markerSignSave MarkerSign a ser armazenado
     * @param statement PreparedStatement contendo SQL
     * @throws java.sql.SQLException
     * @param markerOwner Marker owner
     */
    private static void obj2stmt(MarkerSign markerSignSave, org.soluc.model.marker.Marker markerOwner, java.sql.PreparedStatement statement) throws java.sql.SQLException {
        statement.setInt(1, markerOwner.getId());
        statement.setInt(2, markerSignSave.getMember());
        statement.setDate(3, new java.sql.Date(markerSignSave.getWhen().getTime()));
        statement.setInt(4, markerSignSave.getType());
    }

    /** insert - Este método insere no BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param markerSignInsert MarkerSign a ser inserido
     * @param markerOwner Marker owner
     * @throws java.sql.SQLException
     */
    public static void insert(java.sql.Connection connection, MarkerSign markerSignInsert, org.soluc.model.marker.Marker markerOwner) throws java.sql.SQLException {
        String sql = "INSERT INTO MarkerSign (markerOwner,member,when,type) "
                   + "VALUES (?,?,?,?)";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        obj2stmt(markerSignInsert, markerOwner, statement);
        statement.executeUpdate();
        statement.close();
        sql = "SELECT IDENTITY_VAL_LOCAL() FROM MarkerSign";
        statement = connection.prepareStatement(sql);
        java.sql.ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            markerSignInsert.setId(resultSet.getInt(1));
        }
        statement.close();
    }

    /** update - Este método atualiza no BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param markerSignUpdate MarkerSign a ser atualizado
     * @param markerOwner Marker owner
     * @throws java.sql.SQLException
     */
    public static void update(java.sql.Connection connection, MarkerSign markerSignUpdate, org.soluc.model.marker.Marker markerOwner) throws java.sql.SQLException {
        String sql = "UPDATE MarkerSign SET "
                   + "markerOwner = ?,"
                   + "member = ?,"
                   + "when = ?,"
                   + "type = ? "
                   + "WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        obj2stmt(markerSignUpdate, markerOwner, statement);
        statement.setInt(5, markerSignUpdate.getId());
        statement.executeUpdate();
        statement.close();
    }

    /** delete - Este método apaga do BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param markerSignDelete MarkerSign a ser apagado
     * @throws java.sql.SQLException
     */
    public static void delete(java.sql.Connection connection, MarkerSign markerSignDelete) throws java.sql.SQLException {
        String sql = "DELETE FROM MarkerSign WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, markerSignDelete.getId());
        statement.executeUpdate();
        statement.close();
    }

    //*****************************************
    //QUERY private
    //*****************************************

    /**
     * rs2obj - Transfere do ResultSet da Query SQL para um novo objeto
     * @param connection
     * @param resultSet to parse
     * @return novo objeto
     * @throws java.sql.SQLException 
     */
    private static MarkerSign rs2obj(java.sql.Connection connection, java.sql.ResultSet resultSet) throws java.sql.SQLException {
        MarkerSign markerSignLoad = new MarkerSign();
        markerSignLoad.setId(resultSet.getInt("id"));
        markerSignLoad.setMember(resultSet.getInt("member"));
        markerSignLoad.setWhen(resultSet.getDate("when"));
        markerSignLoad.setType(resultSet.getInt("type"));
        return markerSignLoad;
    }

    /** load - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param condition Condição WHERE
     * @return objeto MarkerSign || null caso não encontrar
     * @throws java.sql.SQLException
     */
    private static MarkerSign load(java.sql.Connection connection, String condition) throws java.sql.SQLException {
        if(!condition.isEmpty()){
            String sql = "SELECT id,member,when,type "
                       + "FROM MarkerSign "
                       + "WHERE "+condition;
            java.sql.PreparedStatement statement = connection.prepareStatement(sql);
            java.sql.ResultSet resultSet = statement.executeQuery();
            MarkerSign markerSignLoad;
            if (resultSet.next()) {
                markerSignLoad = rs2obj(connection, resultSet);
            } else {
                markerSignLoad = null;
            }
            statement.close();
            return markerSignLoad;
        } else {
            return null;
        }
    }

    /** loadList - Carrega lista de objetos MarkerSign
     * @param connection Conexão com BD
     * @param condition Condição WHERE
     * @return List contendo a tabela
     */
    private static java.util.List<MarkerSign> loadList(java.sql.Connection connection, String condition) {
        java.util.List<MarkerSign> list = new java.util.ArrayList<MarkerSign>();
        try {
            String sql = "SELECT id,member,when,type "
                       + "FROM MarkerSign "
                       + (condition.isEmpty()?"":"WHERE "+condition);
            java.sql.PreparedStatement statement = connection.prepareStatement(sql);
            java.sql.ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                MarkerSign markerSignLoad = rs2obj(connection, resultSet);
                list.add(markerSignLoad);
            }
            statement.close();
        } catch (java.sql.SQLException sqlex) {
            System.out.println("Falha na leitura do banco de dados !\n"+sqlex.getMessage());
        }
        return list;
    }

    /** loadView - Carrega visão de atributos de objetos MarkerSign
     * @param connection Conexão com BD
     * @param attributesList Atributos listados
     * @param condition condição WHERE
     * @param order Ordem da lista
     * @return lista de atributo
     */
    private static java.util.List loadView(java.sql.Connection connection, String attributesList, String condition, String order) {
        String sql = "SELECT " + attributesList + " "
                   + "FROM MarkerSign "
                   + (condition.isEmpty() ? "" : "WHERE " + condition)
                   + (order.isEmpty() ? "" : "ORDER BY " + order);
        return execQueryF(connection, sql);
    }

    //*****************************************
    //QUERY public
    //*****************************************

    //*****************************************
    //LOAD Object BY
    //*****************************************

    /** loadById - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de MarkerSign
     * @return objeto MarkerSign || null caso não encontrar
     * @throws java.sql.SQLException
     */
    public static MarkerSign loadById(java.sql.Connection connection, Integer id) throws java.sql.SQLException {
        return load(connection, "id = "+id);
    }

    //*****************************************
    //EXISTS Object BY
    //*****************************************

    /** existsById - Este método verifica a existência de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de MarkerSign
     * @return true caso exista || false caso não exista
     */
    public static Boolean existsById(java.sql.Connection connection, Integer id) {
        java.util.List<MarkerSign> l = loadList(connection, "id="+id);
        return !l.isEmpty();
    }

    //*****************************************
    //LOAD Attribute List
    //*****************************************

    /** loadIdList - Carrega lista de id de objetos MarkerSign
     * @param connection Conexão com BD
     * @return List contendo Id
     */
    public static java.util.List<String> loadIdList(java.sql.Connection connection) {
        return loadView(connection, "id", "", "id");
    }

    //*****************************************
    //LOAD Object List
    //*****************************************

    /** loadList - Retorna Lista de objetos MarkerSign por Marker
     * @param connection Conexão com BD
     * @param markerOwner Marker
     * @return List contendo os objetos
     */
    public static java.util.List<MarkerSign> loadList(java.sql.Connection connection, org.soluc.model.marker.Marker markerOwner) {
        return loadList(connection, "markerOwner = " + markerOwner.getId());
    }

    //*****************************************
    //LOAD Object View
    //*****************************************

}
