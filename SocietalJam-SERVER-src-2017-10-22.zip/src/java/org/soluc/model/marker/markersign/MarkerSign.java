package org.soluc.model.marker.markersign;
/**
 *
 * @author JSQLGen
 */
public final class MarkerSign {

    /** Atributos estaticos */
    public static String[] TYPE = {
        "Apropriado",
        "Inapropriado"
    };

    /** Atributos */
    private Integer id;
    private Integer member;
    private java.util.Date when;
    private Integer type;

    /** Construtor */
    public MarkerSign() {
        id = null;
        member = 0;
        when = new java.util.Date();
        type = 0;
    }
    /** Metodos */

    /**
     * @return id
     */
    public Integer getId() { return id; }
    /**
     * @param id Id to set
     */
    public void setId(Integer id) { this.id = id; }
    /**
     * @param id - String id to set
     */
    public void setId(String id) { this.id = (id.equals("null") || id.isEmpty())?null:Integer.parseInt(id); }

    /**
     * @return member
     */
    public Integer getMember() { return member; }
    /**
     * @param member Member to set
     */
    public void setMember(Integer member) { this.member = member; }
    /**
     * @param member - String member to set
     */
    public void setMember(String member) { this.member = Integer.parseInt(member); }

    /**
     * @return When
     */
    public java.util.Date getWhen() { return when; }
    /**
     * @param pattern Formato de When. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @return When Formatado
     */
    public String getWhenF(String pattern) { return new java.text.SimpleDateFormat(pattern).format(when); }
    /**
     * @param when When to set
     */
    public void setWhen(java.util.Date when) { this.when = when; }
    /**
     * @param pattern Formato de When. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @param when - String When to set
     */
    public void setWhenF(String pattern, String when) { this.when = new java.text.SimpleDateFormat(pattern).parse(when, new java.text.ParsePosition(0)); }

    /**
     * @return the type
     */
    public Integer getType() { return type; }
    /**
     * @return the type Formatted
     */
    public String getTypeF() { return TYPE[type]; }
    /**
     * @param type the type to set
     */
    public void setType(Integer type) { this.type = type; }
}
