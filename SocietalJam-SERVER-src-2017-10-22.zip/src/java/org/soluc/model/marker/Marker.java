package org.soluc.model.marker;
/**
 *
 * @author JSQLGen
 */
public final class Marker {

    public static int RANGES[] = {0, 19, 30, 34};

    /**
     * Atributos estaticos
     */
    public static String[] TYPE = {
        "-",
        "Problema Urbano - Asfalto danificado",
        "Problema Urbano - Iluminação pública danificada",
        "Problema Urbano - Patrimônio Público danificado",
        "Problema Urbano - Sinalização danificada",
        "Problema Urbano - Falta de coleta de lixo recilável",
        "Problema Urbano - Falta de coleta de lixo orgânico",
        "Problema Urbano - Falta de iluminação pública",
        "Problema Urbano - Falta de pavimentação",
        "Problema Urbano - Falta de policiamento",
        "Problema Urbano - Falta de sinalização",
        "Problema Urbano - Falta de rede de coleta de esgoto",
        "Problema Urbano - Falta de rede de distribuição de água",
        "Problema Urbano - Falta de rede de energia elétrica",
        "Problema Urbano - Falta de acessibilidade",
        "Problema Urbano - Local com vazamento de água",
        "Problema Urbano - Local com Entulho/Lixo acumulado",
        "Problema Urbano - Local com risco de acidente automobilístico",
        "Problema Urbano - Local com risco à população",
        "Problema Urbano - Local com falta de manutenção",
        "Evento - Concurso",
        "Evento - Evento cultural gratuito",
        "Evento - Evento cultural pago",
        "Evento - Evento educacional gratuito",
        "Evento - Evento educacional pago",
        "Evento - Evento esportivo",
        "Evento - Evento social",
        "Evento - Manifestação coletiva",
        "Evento - Circo Itinerante",
        "Evento - Feira Itinerante",
        "Evento - Parque Itinerante",
        "Serviço Gratuito - Banheiro público",
        "Serviço Gratuito - Cabine telefônica",
        "Serviço Gratuito - Câmera pública",
        "Serviço Gratuito - Wifi gratuito",
        "Saúde - Clínica",
        "Saúde - Consultório",
        "Saúde - Farmácia",
        "Saúde - Laboratório",
        "Saúde - Posto médico",
        "Saúde - Hospital",
        "Social - Albergue",
        "Social - Entidade filantrópica",
        "Social - Igreja",
        "Social - Orfanato",
        "Social - Organização Não Governamental",
        "Segurança - Delegacia",
        "Segurança - Posto de bombeiros",
        "Segurança - Posto policial",
        "Segurança - Estabelecimento de detenção",
        "Segurança - Estabelecimento de detenção para menores de idade",
        "Segurança - Quartel militar",
        "Educação - Escola pública de educação básica",
        "Educação - Escola pública de educação superior",
        "Educação - Escola privada de educação básica",
        "Educação - Escola privada de educação superior",
        "Educação - Escola de Educação Especial",
        "Educação - Centro educacional público",
        "Educação - Centro educacional privado",
        "Esporte - Academia",
        "Esporte - Estádio/Ginásio de esportes",
        "Esporte - Área de camping",
        "Esporte - Área de caça / pesca",
        "Cultura/Lazer - Bar",
        "Cultura/Lazer - Clube",
        "Cultura/Lazer - Cinema",
        "Cultura/Lazer - Teatro",
        "Cultura/Lazer - Museu",
        "Cultura/Lazer - Parque",
        "Cultura/Lazer - Parque temático",
        "Cultura/Lazer - Parque de diversões",
        "Cultura/Lazer - Praça",
        "Cultura/Lazer - Playground",
        "Cultura/Lazer - Restaurante",
        "Cultura/Lazer - Hotel / Pousada / Resort",
        "Cultura/Lazer - Zoológico",
        "Cultura/Lazer - Local turístico religioso",
        "Transporte - Aeroporto",
        "Transporte - Estação de trem / metro",
        "Transporte - Estação de ônibus rodoviário",
        "Transporte - Estação de ônibus urbano",
        "Transporte - Ponto de ônibus",
        "Transporte - Ponto de táxi",
        "Transporte - Porto ",
        "Transporte - Transportadora",
        "Transporte - Pedágio",
        "Transporte - Posto de combustível",
        "Transporte - Radar",
        "Utilidade Pública - Agência dos Correios",
        "Utilidade Pública - Banco",
        "Utilidade Pública - Cartório",
        "Utilidade Pública - Departamento público",
        "Utilidade Pública - Fórum",
        "Utilidade Pública - Lotérica",
        "Utilidade Pública - Prefeitura",
        "Comércio - Indústria",
        "Comércio - Comércio no atacado",
        "Comércio - Comércio no varejo",
        "Comércio - Prestação de serviços",
        "Comércio - Profissional liberal"
    };

    /** Atributos */
    private Integer id;
    private Integer type;
    private java.util.Date start;
    private java.util.Date finish;
    private Double latitude;
    private Double longitude;
    private Integer member;
    private java.util.List<org.soluc.model.marker.markercomment.MarkerComment> comments;
    private java.util.List<org.soluc.model.marker.markersign.MarkerSign> signs;
    private java.util.List<org.soluc.model.marker.markerphoto.MarkerPhoto> photos;

    /** Construtor */
    public Marker() {
        id = null;
        type = 0;
        start = new java.util.Date();
        setFinishF("dd/MM/yyyy","01/01/0001");
        latitude = 0.0;
        longitude = 0.0;
        member = 0;
        comments = new java.util.ArrayList<>();
        signs = new java.util.ArrayList<>();
        photos = new java.util.ArrayList<>();
    }
    /** Metodos */

    /**
     * @return id
     */
    public Integer getId() { return id; }
    /**
     * @param id Id to set
     */
    public void setId(Integer id) { this.id = id; }
    /**
     * @param id - String id to set
     */
    public void setId(String id) { this.id = (id.equals("null") || id.isEmpty())?null:Integer.parseInt(id); }

    /**
     * @return the type
     */
    public Integer getType() { return type; }
    /**
     * @return the type Formatted
     */
    public String getTypeF() { return TYPE[type]; }
    /**
     * @param type the type to set
     */
    public void setType(Integer type) { this.type = type; }
    /**
     * @param type the type to set
     */
    public void setType(String type) { this.type = Integer.parseInt(type); }

    /**
     * @return Start
     */
    public java.util.Date getStart() { return start; }
    /**
     * @param pattern Formato de Start. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @return Start Formatado
     */
    public String getStartF(String pattern) { return new java.text.SimpleDateFormat(pattern).format(start); }
    /**
     * @param start Start to set
     */
    public void setStart(java.util.Date start) { this.start = start; }
    /**
     * @param pattern Formato de Start. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @param start - String Start to set
     */
    public void setStartF(String pattern, String start) { this.start = new java.text.SimpleDateFormat(pattern).parse(start, new java.text.ParsePosition(0)); }

    /**
     * @return Finish
     */
    public java.util.Date getFinish() { return finish; }
    /**
     * @param pattern Formato de Finish. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @return Finish Formatado
     */
    public String getFinishF(String pattern) { return new java.text.SimpleDateFormat(pattern).format(finish); }
    /**
     * @param finish Finish to set
     */
    public void setFinish(java.util.Date finish) { this.finish = finish; }
    /**
     * @param pattern Formato de Finish. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @param finish - String Finish to set
     */
    public void setFinishF(String pattern, String finish) { this.finish = new java.text.SimpleDateFormat(pattern).parse(finish, new java.text.ParsePosition(0)); }

    /**
     * @return latitude
     */
    public Double getLatitude() { return latitude; }
    /**
     * @param latitude Latitude to set
     */
    public void setLatitude(Double latitude) { this.latitude = latitude; }
    /**
     * @param latitude Latitude to set
     */
    public void setLatitude(String latitude) { this.latitude = Double.parseDouble(latitude); }

    /**
     * @return longitude
     */
    public Double getLongitude() { return longitude; }
    /**
     * @param longitude Longitude to set
     */
    public void setLongitude(Double longitude) { this.longitude = longitude; }
    /**
     * @param longitude Longitude to set
     */
    public void setLongitude(String longitude) { this.longitude = Double.parseDouble(longitude); }

    /**
     * @return member
     */
    public Integer getMember() { return member; }
    /**
     * @param member Member to set
     */
    public void setMember(Integer member) { this.member = member; }
    /**
     * @param member - String member to set
     */
    public void setMember(String member) { this.member = Integer.parseInt(member); }

    /**
     * @return the comments
     */
    public java.util.List<org.soluc.model.marker.markercomment.MarkerComment> getComments() { return comments; }
    /**
     * @param comments the comments to set
     */
    public void setComments(java.util.List<org.soluc.model.marker.markercomment.MarkerComment> comments) { this.comments = comments; }

    /**
     * @return the signs
     */
    public java.util.List<org.soluc.model.marker.markersign.MarkerSign> getSigns() { return signs; }
    /**
     * @param signs the signs to set
     */
    public void setSigns(java.util.List<org.soluc.model.marker.markersign.MarkerSign> signs) { this.signs = signs; }

    /**
     * @return the photos
     */
    public java.util.List<org.soluc.model.marker.markerphoto.MarkerPhoto> getPhotos() { return photos; }
    /**
     * @param photos the photos to set
     */
    public void setPhotos(java.util.List<org.soluc.model.marker.markerphoto.MarkerPhoto> photos) { this.photos = photos; }
}
