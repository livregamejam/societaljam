package org.soluc.model.member.memberphoto;
/**
 *
 * @author JSQLGen
 */
public final class MemberPhoto {


    /** Atributos */
    private Integer id;
    private java.util.Date when;
    private javax.swing.ImageIcon photo;

    /** Construtor */
    public MemberPhoto() {
        id = null;
        when = new java.util.Date();
        photo = new javax.swing.ImageIcon();
    }
    /** Metodos */

    /**
     * @return id
     */
    public Integer getId() { return id; }
    /**
     * @param id Id to set
     */
    public void setId(Integer id) { this.id = id; }
    /**
     * @param id - String id to set
     */
    public void setId(String id) { this.id = (id.equals("null") || id.isEmpty())?null:Integer.parseInt(id); }

    /**
     * @return When
     */
    public java.util.Date getWhen() { return when; }
    /**
     * @param pattern Formato de When. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @return When Formatado
     */
    public String getWhenF(String pattern) { return new java.text.SimpleDateFormat(pattern).format(when); }
    /**
     * @param when When to set
     */
    public void setWhen(java.util.Date when) { this.when = when; }
    /**
     * @param pattern Formato de When. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @param when - String When to set
     */
    public void setWhenF(String pattern, String when) { this.when = new java.text.SimpleDateFormat(pattern).parse(when, new java.text.ParsePosition(0)); }

    /**
     * @return Photo
     */
    public javax.swing.ImageIcon getPhoto() { return photo; }
    /**
     * @param formatName - a String containg the informal name of the format.(PNG,JPEG,GIF)
     * @return the ByteArrayInputStream representing the Photo.
     */
    public java.io.ByteArrayInputStream getPhoto(String formatName) {
        try {
            java.awt.image.BufferedImage bf = new java.awt.image.BufferedImage(photo.getIconWidth(),photo.getIconHeight(),java.awt.image.BufferedImage.TYPE_INT_ARGB);
            bf.createGraphics().drawImage(photo.getImage(), null, null);
            java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
            //javax.imageio.ImageIO.write(bf,"PNG",output);
            javax.imageio.ImageIO.write(bf,formatName,output);
            return new java.io.ByteArrayInputStream(output.toByteArray());
        } catch(java.io.IOException e){
            return new java.io.ByteArrayInputStream(new byte[0]);
        } catch(IllegalArgumentException  e){
            return new java.io.ByteArrayInputStream(new byte[0]);
        }
    }
    /**
     * @param photo Photo to set
     */
    public void setPhoto(javax.swing.ImageIcon photo) { this.photo = photo; }
    /**
     * @param photo Photo to set
     * @param width Photo fixed width
     */
    public void setPhoto(javax.swing.ImageIcon photo, int width) {
        width = Math.abs(width);
        if(width==0) width = photo.getIconWidth();
        int height = (width*photo.getIconHeight()) / photo.getIconWidth();
        java.awt.image.BufferedImage bf = new java.awt.image.BufferedImage(width, height,java.awt.image.BufferedImage.TYPE_INT_ARGB);
        bf.createGraphics().drawImage(photo.getImage(), 0, 0, width, height, null);
        this.photo = new javax.swing.ImageIcon(bf);
    }
    /**
     * Salva Photo em arquivo
     * @param path - path file
     * @param format - JPG,PNG,GIF
     * @throws java.io.IOException 
     */
    public void savePhoto(String path, String format) throws java.io.IOException{
        java.awt.image.BufferedImage bf = new java.awt.image.BufferedImage(photo.getIconWidth(),photo.getIconHeight(),java.awt.image.BufferedImage.TYPE_INT_ARGB);
        bf.createGraphics().drawImage(photo.getImage(), null, null);
        java.io.File file = new java.io.File(path);
        javax.imageio.ImageIO.write(bf,format,file);
    }
    /**
     * Carrega arquivo de imagem para Photo
     * @param path - path file
     */
    public void loadPhoto(String path) {
        this.photo = new javax.swing.ImageIcon(path);
    }
}
