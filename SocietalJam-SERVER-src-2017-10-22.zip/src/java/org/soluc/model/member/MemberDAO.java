package org.soluc.model.member;

/**
 * Class MemberDAO responsável pela 
 * leitura/escrita de objetos Member no BD
 *
 * @author JSQLGen
 */
public final class MemberDAO extends dbaccess.DAO {

    //*****************************************
    //CREATE TABLE
    //*****************************************

    /** createTable - Cria a tabela Member no BD
     * @param connection Conexão com BD
     * @throws java.sql.SQLException
     */
    public static void createTable(java.sql.Connection connection) throws java.sql.SQLException {
        String sql = "CREATE TABLE Member ("
                   + "id INT NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH 0, INCREMENT BY 1),"
                   + "active BOOLEAN NOT NULL,"
                   + "membersince DATE NOT NULL,"
                   + "firstname VARCHAR(50) NOT NULL,"
                   + "middlename VARCHAR(50) NOT NULL,"
                   + "lastname VARCHAR(50) NOT NULL,"
                   + "gender INT NOT NULL,"
                   + "birthdate DATE NOT NULL,"
                   + "nickname VARCHAR(30) UNIQUE NOT NULL,"
                   + "email VARCHAR(70) UNIQUE NOT NULL,"
                   + "password VARCHAR(100) NOT NULL,"
                   + "CONSTRAINT PK_Member PRIMARY KEY (id)"
                   + ")";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.executeUpdate();
        statement.close();

        sql = "CREATE INDEX IDX_Member_membersince ON Member (membersince)";
        statement = connection.prepareStatement(sql);
        statement.executeUpdate();
        statement.close();

        org.soluc.model.member.memberphoto.MemberPhotoDAO.createTable(connection);
    }

    //*****************************************
    //UPDATE
    //*****************************************

    /** obj2stmt - Transfere o Objeto para o PreparedStatement.
     * @param connection Conexão com BD
     * @param memberSave Member a ser armazenado
     * @param statement PreparedStatement contendo SQL
     * @throws java.sql.SQLException
     */
    private static void obj2stmt(Member memberSave, java.sql.PreparedStatement statement) throws java.sql.SQLException {
        statement.setBoolean(1, memberSave.getActive());
        statement.setDate(2, new java.sql.Date(memberSave.getMembersince().getTime()));
        statement.setString(3, memberSave.getFirstname());
        statement.setString(4, memberSave.getMiddlename());
        statement.setString(5, memberSave.getLastname());
        statement.setInt(6, memberSave.getGender());
        statement.setDate(7, new java.sql.Date(memberSave.getBirthdate().getTime()));
        statement.setString(8, memberSave.getNickname());
        statement.setString(9, memberSave.getEmail());
        statement.setString(10, memberSave.getPassword());
    }

    /** insert - Este método insere no BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param memberInsert Member a ser inserido
     * @throws java.sql.SQLException
     */
    public static void insert(java.sql.Connection connection, Member memberInsert) throws java.sql.SQLException {
        String sql = "INSERT INTO Member (active,membersince,firstname,middlename,lastname,gender,birthdate,nickname,email,password) "
                   + "VALUES (?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        obj2stmt(memberInsert, statement);
        statement.executeUpdate();
        statement.close();
        sql = "SELECT IDENTITY_VAL_LOCAL() FROM Member";
        statement = connection.prepareStatement(sql);
        java.sql.ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            memberInsert.setId(resultSet.getInt(1));
        }
        statement.close();
        for (org.soluc.model.member.memberphoto.MemberPhoto memberphotoInsert : memberInsert.getImages()) {
            org.soluc.model.member.memberphoto.MemberPhotoDAO.insert(connection, memberphotoInsert, memberInsert);
        }
    }

    /** update - Este método atualiza no BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param memberUpdate Member a ser atualizado
     * @throws java.sql.SQLException
     */
    public static void update(java.sql.Connection connection, Member memberUpdate) throws java.sql.SQLException {
        String sql = "UPDATE Member SET "
                   + "active = ?,"
                   + "membersince = ?,"
                   + "firstname = ?,"
                   + "middlename = ?,"
                   + "lastname = ?,"
                   + "gender = ?,"
                   + "birthdate = ?,"
                   + "nickname = ?,"
                   + "email = ?,"
                   + "password = ? "
                   + "WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        obj2stmt(memberUpdate, statement);
        statement.setInt(11, memberUpdate.getId());
        statement.executeUpdate();
        statement.close();
    }

    /** delete - Este método apaga do BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param memberDelete Member a ser apagado
     * @throws java.sql.SQLException
     */
    public static void delete(java.sql.Connection connection, Member memberDelete) throws java.sql.SQLException {
        String sql = "DELETE FROM Member WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, memberDelete.getId());
        statement.executeUpdate();
        statement.close();
    }

    //*****************************************
    //QUERY private
    //*****************************************

    /**
     * rs2obj - Transfere do ResultSet da Query SQL para um novo objeto
     * @param connection
     * @param resultSet to parse
     * @return novo objeto
     * @throws java.sql.SQLException 
     */
    private static Member rs2obj(java.sql.Connection connection, java.sql.ResultSet resultSet) throws java.sql.SQLException {
        Member memberLoad = new Member();
        memberLoad.setId(resultSet.getInt("id"));
        memberLoad.setActive(resultSet.getBoolean("active"));
        memberLoad.setMembersince(resultSet.getDate("membersince"));
        memberLoad.setFirstname(resultSet.getString("firstname"));
        memberLoad.setMiddlename(resultSet.getString("middlename"));
        memberLoad.setLastname(resultSet.getString("lastname"));
        memberLoad.setGender(resultSet.getInt("gender"));
        memberLoad.setBirthdate(resultSet.getDate("birthdate"));
        memberLoad.setNickname(resultSet.getString("nickname"));
        memberLoad.setEmail(resultSet.getString("email"));
        memberLoad.setPassword(resultSet.getString("password"));
        memberLoad.setImages(org.soluc.model.member.memberphoto.MemberPhotoDAO.loadList(connection, memberLoad));
        return memberLoad;
    }

    /** load - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param condition Condição WHERE
     * @return objeto Member || null caso não encontrar
     * @throws java.sql.SQLException
     */
    private static Member load(java.sql.Connection connection, String condition) throws java.sql.SQLException {
        if(!condition.isEmpty()){
            String sql = "SELECT id,active,membersince,firstname,middlename,lastname,gender,birthdate,nickname,email,password "
                       + "FROM Member "
                       + "WHERE "+condition;
            java.sql.PreparedStatement statement = connection.prepareStatement(sql);
            java.sql.ResultSet resultSet = statement.executeQuery();
            Member memberLoad;
            if (resultSet.next()) {
                memberLoad = rs2obj(connection, resultSet);
            } else {
                memberLoad = null;
            }
            statement.close();
            return memberLoad;
        } else {
            return null;
        }
    }

    /** loadList - Carrega lista de objetos Member
     * @param connection Conexão com BD
     * @param condition Condição WHERE
     * @return List contendo a tabela
     */
    private static java.util.List<Member> loadList(java.sql.Connection connection, String condition) {
        java.util.List<Member> list = new java.util.ArrayList<Member>();
        try {
            String sql = "SELECT id,active,membersince,firstname,middlename,lastname,gender,birthdate,nickname,email,password "
                       + "FROM Member "
                       + (condition.isEmpty()?"":"WHERE "+condition);
            java.sql.PreparedStatement statement = connection.prepareStatement(sql);
            java.sql.ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Member memberLoad = rs2obj(connection, resultSet);
                list.add(memberLoad);
            }
            statement.close();
        } catch (java.sql.SQLException sqlex) {
            System.out.println("Falha na leitura do banco de dados !\n"+sqlex.getMessage());
        }
        return list;
    }

    /** loadView - Carrega visão de atributos de objetos Member
     * @param connection Conexão com BD
     * @param attributesList Atributos listados
     * @param condition condição WHERE
     * @param order Ordem da lista
     * @return lista de atributo
     */
    private static java.util.List loadView(java.sql.Connection connection, String attributesList, String condition, String order) {
        String sql = "SELECT " + attributesList + " "
                   + "FROM Member "
                   + (condition.isEmpty() ? "" : "WHERE " + condition)
                   + (order.isEmpty() ? "" : "ORDER BY " + order);
        return execQueryF(connection, sql);
    }

    //*****************************************
    //QUERY public
    //*****************************************

    //*****************************************
    //LOAD Object BY
    //*****************************************

    /** loadById - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de Member
     * @return objeto Member || null caso não encontrar
     * @throws java.sql.SQLException
     */
    public static Member loadById(java.sql.Connection connection, Integer id) throws java.sql.SQLException {
        return load(connection, "id = "+id);
    }

    /** loadByNickname - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param nickname campo identificador de Member
     * @return objeto Member || null caso não encontrar
     * @throws java.sql.SQLException
     */
    public static Member loadByNickname(java.sql.Connection connection, String nickname) throws java.sql.SQLException {
        return load(connection, "nickname = '"+nickname+"'");
    }

    /** loadByEmail - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param email campo identificador de Member
     * @return objeto Member || null caso não encontrar
     * @throws java.sql.SQLException
     */
    public static Member loadByEmail(java.sql.Connection connection, String email) throws java.sql.SQLException {
        return load(connection, "email = '"+email+"'");
    }

    //*****************************************
    //EXISTS Object BY
    //*****************************************

    /** existsById - Este método verifica a existência de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de Member
     * @return true caso exista || false caso não exista
     */
    public static Boolean existsById(java.sql.Connection connection, Integer id) {
        java.util.List<Member> l = loadList(connection, "id="+id);
        return !l.isEmpty();
    }

    /** existsByNickname - Este método verifica a existência de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param nickname campo identificador de Member
     * @return true caso exista || false caso não exista
     */
    public static Boolean existsByNickname(java.sql.Connection connection, String nickname) {
        java.util.List<Member> l = loadList(connection, "nickname='"+nickname+"'");
        return !l.isEmpty();
    }

    /** existsByEmail - Este método verifica a existência de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param email campo identificador de Member
     * @return true caso exista || false caso não exista
     */
    public static Boolean existsByEmail(java.sql.Connection connection, String email) {
        java.util.List<Member> l = loadList(connection, "email='"+email+"'");
        return !l.isEmpty();
    }

    //*****************************************
    //GET Unique Attribute BY 
    //*****************************************

    /** getNicknameById - Este método carrega o campo de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de Member
     * @return nickname || null caso não exista
     */
    public static String getNicknameById(java.sql.Connection connection, Integer id) {
        java.util.List l = execQuery(connection, "SELECT nickname FROM Member WHERE id="+id);
        if(!l.isEmpty()){
            return(String)l.get(0);
        } else {
            return null;
        }
    }

    /** getEmailById - Este método carrega o campo de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de Member
     * @return email || null caso não exista
     */
    public static String getEmailById(java.sql.Connection connection, Integer id) {
        java.util.List l = execQuery(connection, "SELECT email FROM Member WHERE id="+id);
        if(!l.isEmpty()){
            return(String)l.get(0);
        } else {
            return null;
        }
    }

    /** getIdByNickname - Este método carrega o campo de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param nickname campo identificador de Member
     * @return id || null caso não exista
     */
    public static Integer getIdByNickname(java.sql.Connection connection, String nickname) {
        java.util.List l = execQuery(connection, "SELECT id FROM Member WHERE nickname='"+nickname+"'");
        if(!l.isEmpty()){
            return(Integer)l.get(0);
        } else {
            return null;
        }
    }

    /** getEmailByNickname - Este método carrega o campo de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param nickname campo identificador de Member
     * @return email || null caso não exista
     */
    public static String getEmailByNickname(java.sql.Connection connection, String nickname) {
        java.util.List l = execQuery(connection, "SELECT email FROM Member WHERE nickname='"+nickname+"'");
        if(!l.isEmpty()){
            return(String)l.get(0);
        } else {
            return null;
        }
    }

    /** getIdByEmail - Este método carrega o campo de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param email campo identificador de Member
     * @return id || null caso não exista
     */
    public static Integer getIdByEmail(java.sql.Connection connection, String email) {
        java.util.List l = execQuery(connection, "SELECT id FROM Member WHERE email='"+email+"'");
        if(!l.isEmpty()){
            return(Integer)l.get(0);
        } else {
            return null;
        }
    }

    /** getNicknameByEmail - Este método carrega o campo de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param email campo identificador de Member
     * @return nickname || null caso não exista
     */
    public static String getNicknameByEmail(java.sql.Connection connection, String email) {
        java.util.List l = execQuery(connection, "SELECT nickname FROM Member WHERE email='"+email+"'");
        if(!l.isEmpty()){
            return(String)l.get(0);
        } else {
            return null;
        }
    }

    //*****************************************
    //LOAD Attribute List
    //*****************************************

    /** loadIdList - Carrega lista de id de objetos Member
     * @param connection Conexão com BD
     * @return List contendo Id
     */
    public static java.util.List<String> loadIdList(java.sql.Connection connection) {
        return loadView(connection, "id", "", "id");
    }

    /** loadNicknameList - Carrega lista de nickname de objetos Member
     * @param connection Conexão com BD
     * @return List contendo Nickname
     */
    public static java.util.List<String> loadNicknameList(java.sql.Connection connection) {
        return loadView(connection, "nickname", "", "nickname");
    }

    /** loadEmailList - Carrega lista de email de objetos Member
     * @param connection Conexão com BD
     * @return List contendo Email
     */
    public static java.util.List<String> loadEmailList(java.sql.Connection connection) {
        return loadView(connection, "email", "", "email");
    }

    //*****************************************
    //LOAD Object List
    //*****************************************

    /** loadList - Carrega lista de objetos Member
     * @param connection Conexão com BD
     * @return List contendo os objetos
     */
    public static java.util.List<Member> loadList(java.sql.Connection connection) {
        return loadList(connection, "");
    }

    //*****************************************
    //LOAD Object View
    //*****************************************

    /** loadView - Carrega visão de atributos de objetos Member
     * @param connection Conexão com BD
     * @return lista com visão de atributos
     */
    public static java.util.List loadView(java.sql.Connection connection) {
        String sql = "SELECT "
                   + "Member.id,"
                   + "Member.active,"
                   + "Member.membersince,"
                   + "Member.firstname,"
                   + "Member.middlename,"
                   + "Member.lastname,"
                   + "Member.gender,"
                   + "Member.birthdate,"
                   + "Member.nickname,"
                   + "Member.email,"
                   + "Member.password "
                   + "FROM Member ";
        return execQueryF(connection, sql);
    }

}
