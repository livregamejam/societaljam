package org.soluc.model.member;
/**
 *
 * @author JSQLGen
 */
public final class Member {

    /** Atributos estaticos */
    public static String[] GENDER = {
        "Masculino",
        "Feminino"
    };

    /** Atributos */
    private Integer id;
    private Boolean active;
    private java.util.Date membersince;
    private String firstname;
    private String middlename;
    private String lastname;
    private Integer gender;
    private java.util.Date birthdate;
    private String nickname;
    private String email;
    private String password;
    private java.util.List<org.soluc.model.member.memberphoto.MemberPhoto> images;

    /** Construtor */
    public Member() {
        id = null;
        active = true;
        membersince = new java.util.Date();
        firstname = "";
        middlename = "";
        lastname = "";
        gender = 0;
        setBirthdateF("dd/MM/yyyy","01/01/0001");
        nickname = null;
        email = null;
        password = "";
        images = new java.util.ArrayList<>();
    }
    /** Metodos */

    /**
     * @return id
     */
    public Integer getId() { return id; }
    /**
     * @param id Id to set
     */
    public void setId(Integer id) { this.id = id; }
    /**
     * @param id - String id to set
     */
    public void setId(String id) { this.id = (id.equals("null") || id.isEmpty())?null:Integer.parseInt(id); }

    /**
     * @return active
     */
    public Boolean isActive() { return active; }
    public Boolean getActive() { return active; }
    /**
     * @param active Active to set
     */
    public void setActive(Boolean active) { this.active = active; }

    /**
     * @return Membersince
     */
    public java.util.Date getMembersince() { return membersince; }
    /**
     * @param pattern Formato de Membersince. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @return Membersince Formatado
     */
    public String getMembersinceF(String pattern) { return new java.text.SimpleDateFormat(pattern).format(membersince); }
    /**
     * @param membersince Membersince to set
     */
    public void setMembersince(java.util.Date membersince) { this.membersince = membersince; }
    /**
     * @param pattern Formato de Membersince. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @param membersince - String Membersince to set
     */
    public void setMembersinceF(String pattern, String membersince) { this.membersince = new java.text.SimpleDateFormat(pattern).parse(membersince, new java.text.ParsePosition(0)); }

    /**
     * @return firstname
     */
    public String getFirstname() { return firstname; }
    /**
     * @param firstname Firstname to set
     */
    public void setFirstname(String firstname) { this.firstname = (firstname.length()>50?firstname.substring(0,50):firstname).replace('\'','`'); }

    /**
     * @return middlename
     */
    public String getMiddlename() { return middlename; }
    /**
     * @param middlename Middlename to set
     */
    public void setMiddlename(String middlename) { this.middlename = (middlename.length()>50?middlename.substring(0,50):middlename).replace('\'','`'); }

    /**
     * @return lastname
     */
    public String getLastname() { return lastname; }
    /**
     * @param lastname Lastname to set
     */
    public void setLastname(String lastname) { this.lastname = (lastname.length()>50?lastname.substring(0,50):lastname).replace('\'','`'); }

    /**
     * @return the gender
     */
    public Integer getGender() { return gender; }
    /**
     * @return the gender Formatted
     */
    public String getGenderF() { return GENDER[gender]; }
    /**
     * @param gender the gender to set
     */
    public void setGender(Integer gender) { this.gender = gender; }

    /**
     * @return Birthdate
     */
    public java.util.Date getBirthdate() { return birthdate; }
    /**
     * @param pattern Formato de Birthdate. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @return Birthdate Formatado
     */
    public String getBirthdateF(String pattern) { return new java.text.SimpleDateFormat(pattern).format(birthdate); }
    /**
     * @param birthdate Birthdate to set
     */
    public void setBirthdate(java.util.Date birthdate) { this.birthdate = birthdate; }
    /**
     * @param pattern Formato de Birthdate. Ex "yyyy-MM-dd" ou "dd/MM/yyyy"
     * @param birthdate - String Birthdate to set
     */
    public void setBirthdateF(String pattern, String birthdate) { this.birthdate = new java.text.SimpleDateFormat(pattern).parse(birthdate, new java.text.ParsePosition(0)); }

    /**
     * @return nickname
     */
    public String getNickname() { return nickname; }
    /**
     * @param nickname Nickname to set
     */
    public void setNickname(String nickname) { this.nickname = (nickname.length()>30?nickname.substring(0,30):nickname).replace('\'','`'); }

    /**
     * @return email
     */
    public String getEmail() { return email; }
    /**
     * @param email Email to set
     */
    public void setEmail(String email) { this.email = (email.length()>70?email.substring(0,70):email).replace('\'','`'); }

    /**
     * @return password
     */
    public String getPassword() { return password; }
    /**
     * @param password Password to set
     */
    public void setPassword(String password) { this.password = (password.length()>100?password.substring(0,100):password).replace('\'','`'); }

    /**
     * @return the images
     */
    public java.util.List<org.soluc.model.member.memberphoto.MemberPhoto> getImages() { return images; }
    /**
     * @param images the images to set
     */
    public void setImages(java.util.List<org.soluc.model.member.memberphoto.MemberPhoto> images) { this.images = images; }
}
