package org.soluc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.soluc.dbaccess.DBAccess;
import org.soluc.model.marker.Marker;
import org.soluc.model.marker.MarkerDAO;
import org.soluc.model.marker.markercomment.MarkerComment;
import org.soluc.model.member.Member;
import org.soluc.model.member.MemberDAO;

/**
 *
 * @author marcos
 */
@WebServlet(name = "MainController", urlPatterns = {"/MainController"})
public class MainController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action.compareTo("isConnected") == 0) {
            isConnected(request, response);
        } else if (action.compareTo("logon") == 0) {
            logon(request, response);
        } else if (action.compareTo("logoff") == 0) {
            logoff(request, response);
        } else if (action.compareTo("getUrbanTroubleList") == 0) {
            getUrbanTroubleList(request, response);
        } else if (action.compareTo("getEventList") == 0) {
            getEventList(request, response);
        } else if (action.compareTo("getNearMarkers") == 0) {
            getNearMarkers(request, response);
        } else if (action.compareTo("getMarker") == 0) {
            getMarker(request, response);
        } else if (action.compareTo("saveMarker") == 0) {
            saveMarker(request, response);
        } else {
            response.setContentType("application/json;charset=UTF-8");
            try (PrintWriter out = response.getWriter()) {
                out.print("{\"error\":1}");
            }
        }
    }

    private Member loadUser(DBAccess dbAccess, String user, String password) {
        if (user == null || user.isEmpty() || password == null || password.isEmpty()) {
            return null;
        } else {
            try {
                Member member = MemberDAO.loadByNickname(dbAccess.getConnection(), user);
                if (member.getPassword().equals(password)) {
                    return member;
                } else {
                    return null;
                }
            } catch (SQLException e) {
                return null;
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Main Controller";
    }// </editor-fold>

    private void isConnected(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            DBAccess dbAccess = (DBAccess) request.getSession().getAttribute("dbAccess");
            if (dbAccess != null) {
                out.print("{\"isConnected\" : true}");
            } else {
                out.print("{\"isConnected\" : false}");
            }
        }
    }

    private void logon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            DBAccess dbAccess = (DBAccess) request.getSession().getAttribute("dbAccess");
            if (dbAccess != null) {
                out.print("{\"status\" : 0}");
            } else {
                try {
                    dbAccess = new DBAccess();
                    Member member = loadUser(dbAccess, request.getParameter("user"), request.getParameter("password"));
                    if (member != null) {
                        request.getSession().setAttribute("member", member);
                        request.getSession().setAttribute("dbAccess", dbAccess);
                        out.print("{\"status\" : 1}");
                    } else {
                        dbAccess.disconnect();
                        out.print("{\"status\" : -1}");
                    }
                } catch (ClassNotFoundException | SQLException ex) {
                    out.print("{\"status\" : -1}");
                }
            }
        }
    }

    private void logoff(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            DBAccess dbAccess = (DBAccess) request.getSession().getAttribute("dbAccess");
            if (dbAccess == null) {
                out.print("{\"status\" : 0}");
            } else {
                request.getSession().removeAttribute("dbAccess");
                try {
                    dbAccess.disconnect();
                    out.print("{\"status\" : 1}");
                } catch (SQLException ex) {
                    out.print("{\"status\" : -1}");
                }
            }
        }
    }

    private void getUrbanTroubleList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String json = "{ \"urbanTroubleList\" : [ ";
            for (int i = Marker.RANGES[0]+1; i <= Marker.RANGES[1]; i++) {
                json += "\"" + Marker.TYPE[i].replace("Problema Urbano - ", "") + "\",";
            }
            json = json.substring(0, json.length() - 1);
            json += "] }";
            out.print(json);
        }
    }

    private void getEventList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String json = "{ \"urbanTroubleList\" : [ ";
            for (int i = Marker.RANGES[1]+1; i <= Marker.RANGES[2]; i++) {
                json += "\"" + Marker.TYPE[i].replace("Evento - ", "") + "\",";
            }
            json = json.substring(0, json.length() - 1);
            json += "] }";
            out.print(json);
        }
    }

    private void getNearMarkers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Double latitude = Double.parseDouble(request.getParameter("latitude"));
            Double longitude = Double.parseDouble(request.getParameter("longitude"));
            try {
                DBAccess db = new DBAccess();
                java.util.List markers = MarkerDAO.loadMarkersByCoord(db.getConnection(), latitude, longitude);
                db.disconnect();
                String json = "";
                json += "{\"status\" : 0, ";
                json += "\"markers\" : [ ";
                for (int i = 0; i < markers.size(); i++) {
                    java.util.List row = (java.util.List) markers.get(i);
                    json += "{";
                    json += "\"id\" : " + row.get(0) + ", ";
                    json += "\"type\" : " + row.get(1) + ", ";
                    json += "\"latitude\" : " + row.get(4) + ", ";
                    json += "\"longitude\" : " + row.get(5) + ", ";
                    json += "\"start\" : " + "\""+row.get(2)+"\"";
                    json += "},";
                }
                json = json.substring(0, json.length() - 1);
                json += "] }";
                //System.out.println(json);
                out.println(json);
            } catch (ClassNotFoundException ex) {
                out.println("{\"status\" : -1}");
            } catch (SQLException ex) {
                out.println("{\"status\" : -2}");
            }
        }
    }

    private void getMarker(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Integer id = Integer.parseInt(request.getParameter("id"));
            try {
                DBAccess db = new DBAccess();
                Marker marker = MarkerDAO.loadById(db.getConnection(), id);
                db.disconnect();
                String json = "";
                json += "{\"status\" : 0, ";
                json += "\"marker\" : { ";
                json += "\"id\" : "+marker.getId()+",";
                json += "\"type\" : "+marker.getType()+",";
                json += "\"typeDescription\" : \""+marker.getTypeF()+"\",";
                json += "\"start\" : \""+marker.getStartF("yyyy-MM-dd")+"\",";
                json += "\"finish\" : \""+marker.getFinishF("yyyy-MM-dd")+"\",";
                json += "\"latitude\" : "+marker.getLatitude()+",";
                json += "\"longitude\" : "+marker.getLongitude()+",";
                json += "\"member\" : "+marker.getMember()+",";
                json += "\"comments\" : [";
                for (org.soluc.model.marker.markercomment.MarkerComment comment : marker.getComments()) {
                    json += "{";
                    json += "\"id\" : "+comment.getId()+",";
                    json += "\"member\" : "+comment.getMember()+",";
                    json += "\"when\" : \""+comment.getWhenF("yyyy-MM-dd")+"\",";
                    json += "\"comment\" : \""+comment.getComment()+"\"";
                    json += "},";
                }
                json = json.substring(0, json.length() - 1);
                json += "]";
                
                json += "}";
                json += "}";
                //System.out.println(json);
                out.println(json);
            } catch (ClassNotFoundException ex) {
                out.println("{\"status\" : -1}");
            } catch (SQLException ex) {
                out.println("{\"status\" : -2}");
            }
        }
    }

    private void saveMarker(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            Marker newMarker = new Marker();
            newMarker.setMember(0);
            newMarker.setType(request.getParameter("type"));
            newMarker.setLatitude(request.getParameter("latitude"));
            newMarker.setLongitude(request.getParameter("longitude"));

            MarkerComment title = new MarkerComment();
            title.setMember(newMarker.getMember());
            title.setComment(request.getParameter("title"));
            newMarker.getComments().add(title);

            MarkerComment comment = new MarkerComment();
            comment.setMember(newMarker.getMember());
            comment.setComment(request.getParameter("comment"));
            newMarker.getComments().add(comment);

            try {
                DBAccess db = new DBAccess();
                MarkerDAO.insert(db.getConnection(), newMarker);
                db.disconnect();
                out.println("{\"status\" : 0}");
            } catch (ClassNotFoundException ex) {
                out.println("{\"status\" : -1}");
            } catch (SQLException ex) {
                out.println("{\"status\" : -2}");
            }
        }
    }
}
