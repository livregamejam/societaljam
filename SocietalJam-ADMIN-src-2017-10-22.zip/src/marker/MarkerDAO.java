package marker;

/**
 * Class MarkerDAO responsável pela 
 * leitura/escrita de objetos Marker no BD
 *
 * @author JSQLGen
 */
public final class MarkerDAO extends dbaccess.DAO {

    //*****************************************
    //CREATE TABLE
    //*****************************************

    /** createTable - Cria a tabela Marker no BD
     * @param connection Conexão com BD
     * @throws java.sql.SQLException
     */
    public static void createTable(java.sql.Connection connection) throws java.sql.SQLException {
        String sql = "CREATE TABLE Marker ("
                   + "id INT NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH 1, INCREMENT BY 1),"
                   + "type INT NOT NULL,"
                   + "start DATE NOT NULL,"
                   + "finish DATE NOT NULL,"
                   + "latitude DOUBLE NOT NULL,"
                   + "longitude DOUBLE NOT NULL,"
                   + "member INT NOT NULL,"
                   + "CONSTRAINT PK_Marker PRIMARY KEY (id)"
                   + ")";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.executeUpdate();
        statement.close();

        sql = "CREATE INDEX IDX_Marker_start ON Marker (start)";
        statement = connection.prepareStatement(sql);
        statement.executeUpdate();
        statement.close();

        sql = "CREATE INDEX IDX_Marker_finish ON Marker (finish)";
        statement = connection.prepareStatement(sql);
        statement.executeUpdate();
        statement.close();

        sql = "CREATE INDEX IDX_Marker_latitude ON Marker (latitude)";
        statement = connection.prepareStatement(sql);
        statement.executeUpdate();
        statement.close();

        sql = "CREATE INDEX IDX_Marker_longitude ON Marker (longitude)";
        statement = connection.prepareStatement(sql);
        statement.executeUpdate();
        statement.close();

        marker.markercomment.MarkerCommentDAO.createTable(connection);

        marker.markersign.MarkerSignDAO.createTable(connection);

        marker.markerphoto.MarkerPhotoDAO.createTable(connection);
    }

    //*****************************************
    //UPDATE
    //*****************************************

    /** obj2stmt - Transfere o Objeto para o PreparedStatement.
     * @param connection Conexão com BD
     * @param markerSave Marker a ser armazenado
     * @param statement PreparedStatement contendo SQL
     * @throws java.sql.SQLException
     */
    private static void obj2stmt(Marker markerSave, java.sql.PreparedStatement statement) throws java.sql.SQLException {
        statement.setInt(1, markerSave.getType());
        statement.setDate(2, new java.sql.Date(markerSave.getStart().getTime()));
        statement.setDate(3, new java.sql.Date(markerSave.getFinish().getTime()));
        statement.setDouble(4, markerSave.getLatitude());
        statement.setDouble(5, markerSave.getLongitude());
        statement.setInt(6, markerSave.getMember());
    }

    /** insert - Este método insere no BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param markerInsert Marker a ser inserido
     * @throws java.sql.SQLException
     */
    public static void insert(java.sql.Connection connection, Marker markerInsert) throws java.sql.SQLException {
        String sql = "INSERT INTO Marker (type,start,finish,latitude,longitude,member) "
                   + "VALUES (?,?,?,?,?,?)";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        obj2stmt(markerInsert, statement);
        statement.executeUpdate();
        statement.close();
        sql = "SELECT IDENTITY_VAL_LOCAL() FROM Marker";
        statement = connection.prepareStatement(sql);
        java.sql.ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            markerInsert.setId(resultSet.getInt(1));
        }
        statement.close();
        for (marker.markercomment.MarkerComment markercommentInsert : markerInsert.getComments()) {
            marker.markercomment.MarkerCommentDAO.insert(connection, markercommentInsert, markerInsert);
        }
        for (marker.markersign.MarkerSign markersignInsert : markerInsert.getSigns()) {
            marker.markersign.MarkerSignDAO.insert(connection, markersignInsert, markerInsert);
        }
        for (marker.markerphoto.MarkerPhoto markerphotoInsert : markerInsert.getPhotos()) {
            marker.markerphoto.MarkerPhotoDAO.insert(connection, markerphotoInsert, markerInsert);
        }
    }

    /** update - Este método atualiza no BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param markerUpdate Marker a ser atualizado
     * @throws java.sql.SQLException
     */
    public static void update(java.sql.Connection connection, Marker markerUpdate) throws java.sql.SQLException {
        String sql = "UPDATE Marker SET "
                   + "type = ?,"
                   + "start = ?,"
                   + "finish = ?,"
                   + "latitude = ?,"
                   + "longitude = ?,"
                   + "member = ? "
                   + "WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        obj2stmt(markerUpdate, statement);
        statement.setInt(7, markerUpdate.getId());
        statement.executeUpdate();
        statement.close();
    }

    /** delete - Este método apaga do BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param markerDelete Marker a ser apagado
     * @throws java.sql.SQLException
     */
    public static void delete(java.sql.Connection connection, Marker markerDelete) throws java.sql.SQLException {
        String sql = "DELETE FROM Marker WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, markerDelete.getId());
        statement.executeUpdate();
        statement.close();
    }

    //*****************************************
    //QUERY private
    //*****************************************

    /**
     * rs2obj - Transfere do ResultSet da Query SQL para um novo objeto
     * @param connection
     * @param resultSet to parse
     * @return novo objeto
     * @throws java.sql.SQLException 
     */
    private static Marker rs2obj(java.sql.Connection connection, java.sql.ResultSet resultSet) throws java.sql.SQLException {
        Marker markerLoad = new Marker();
        markerLoad.setId(resultSet.getInt("id"));
        markerLoad.setType(resultSet.getInt("type"));
        markerLoad.setStart(resultSet.getDate("start"));
        markerLoad.setFinish(resultSet.getDate("finish"));
        markerLoad.setLatitude(resultSet.getDouble("latitude"));
        markerLoad.setLongitude(resultSet.getDouble("longitude"));
        markerLoad.setMember(resultSet.getInt("member"));
        markerLoad.setComments(marker.markercomment.MarkerCommentDAO.loadList(connection, markerLoad));
        markerLoad.setSigns(marker.markersign.MarkerSignDAO.loadList(connection, markerLoad));
        markerLoad.setPhotos(marker.markerphoto.MarkerPhotoDAO.loadList(connection, markerLoad));
        return markerLoad;
    }

    /** load - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param condition Condição WHERE
     * @return objeto Marker || null caso não encontrar
     * @throws java.sql.SQLException
     */
    private static Marker load(java.sql.Connection connection, String condition) throws java.sql.SQLException {
        if(!condition.isEmpty()){
            String sql = "SELECT id,type,start,finish,latitude,longitude,member "
                       + "FROM Marker "
                       + "WHERE "+condition;
            java.sql.PreparedStatement statement = connection.prepareStatement(sql);
            java.sql.ResultSet resultSet = statement.executeQuery();
            Marker markerLoad;
            if (resultSet.next()) {
                markerLoad = rs2obj(connection, resultSet);
            } else {
                markerLoad = null;
            }
            statement.close();
            return markerLoad;
        } else {
            return null;
        }
    }

    /** loadList - Carrega lista de objetos Marker
     * @param connection Conexão com BD
     * @param condition Condição WHERE
     * @return List contendo a tabela
     */
    private static java.util.List<Marker> loadList(java.sql.Connection connection, String condition) {
        java.util.List<Marker> list = new java.util.ArrayList<Marker>();
        try {
            String sql = "SELECT id,type,start,finish,latitude,longitude,member "
                       + "FROM Marker "
                       + (condition.isEmpty()?"":"WHERE "+condition);
            java.sql.PreparedStatement statement = connection.prepareStatement(sql);
            java.sql.ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Marker markerLoad = rs2obj(connection, resultSet);
                list.add(markerLoad);
            }
            statement.close();
        } catch (java.sql.SQLException sqlex) {
            System.out.println("Falha na leitura do banco de dados !\n"+sqlex.getMessage());
        }
        return list;
    }

    /** loadView - Carrega visão de atributos de objetos Marker
     * @param connection Conexão com BD
     * @param attributesList Atributos listados
     * @param condition condição WHERE
     * @param order Ordem da lista
     * @return lista de atributo
     */
    private static java.util.List loadView(java.sql.Connection connection, String attributesList, String condition, String order) {
        String sql = "SELECT " + attributesList + " "
                   + "FROM Marker "
                   + (condition.isEmpty() ? "" : "WHERE " + condition)
                   + (order.isEmpty() ? "" : "ORDER BY " + order);
        return execQueryF(connection, sql);
    }

    //*****************************************
    //QUERY public
    //*****************************************

    //*****************************************
    //LOAD Object BY
    //*****************************************

    /** loadById - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de Marker
     * @return objeto Marker || null caso não encontrar
     * @throws java.sql.SQLException
     */
    public static Marker loadById(java.sql.Connection connection, Integer id) throws java.sql.SQLException {
        return load(connection, "id = "+id);
    }

    //*****************************************
    //EXISTS Object BY
    //*****************************************

    /** existsById - Este método verifica a existência de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de Marker
     * @return true caso exista || false caso não exista
     */
    public static Boolean existsById(java.sql.Connection connection, Integer id) {
        java.util.List<Marker> l = loadList(connection, "id="+id);
        return !l.isEmpty();
    }

    //*****************************************
    //LOAD Attribute List
    //*****************************************

    /** loadIdList - Carrega lista de id de objetos Marker
     * @param connection Conexão com BD
     * @return List contendo Id
     */
    public static java.util.List<String> loadIdList(java.sql.Connection connection) {
        return loadView(connection, "id", "", "id");
    }

    //*****************************************
    //LOAD Object List
    //*****************************************

    /** loadList - Carrega lista de objetos Marker
     * @param connection Conexão com BD
     * @return List contendo os objetos
     */
    public static java.util.List<Marker> loadList(java.sql.Connection connection) {
        return loadList(connection, "");
    }

    //*****************************************
    //LOAD Object View
    //*****************************************

    /** loadView - Carrega visão de atributos de objetos Marker
     * @param connection Conexão com BD
     * @return lista com visão de atributos
     */
    public static java.util.List loadView(java.sql.Connection connection) {
        String sql = "SELECT "
                   + "Marker.id,"
                   + "Marker.type,"
                   + "Marker.start,"
                   + "Marker.finish,"
                   + "Marker.latitude,"
                   + "Marker.longitude,"
                   + "Marker.member "
                   + "FROM Marker ";
        return execQueryF(connection, sql);
    }

}
