package member.memberphoto;

/**
 * Class MemberPhotoDAO responsável pela 
 * leitura/escrita de objetos MemberPhoto no BD
 *
 * @author JSQLGen
 */
public final class MemberPhotoDAO extends dbaccess.DAO {

    //*****************************************
    //CREATE TABLE
    //*****************************************

    /** createTable - Cria a tabela MemberPhoto no BD
     * @param connection Conexão com BD
     * @throws java.sql.SQLException
     */
    public static void createTable(java.sql.Connection connection) throws java.sql.SQLException {
        String sql = "CREATE TABLE MemberPhoto ("
                   + "memberOwner INT NOT NULL,"
                   + "id INT NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH 1, INCREMENT BY 1),"
                   + "when DATE NOT NULL,"
                   + "photo BLOB NOT NULL,"
                   + "CONSTRAINT PK_MemberPhoto PRIMARY KEY (id),"
                   + "CONSTRAINT FKC_MemberPhoto_MemberOwner FOREIGN KEY (memberOwner) REFERENCES Member ON DELETE CASCADE"
                   + ")";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.executeUpdate();
        statement.close();
    }

    //*****************************************
    //UPDATE
    //*****************************************

    /** obj2stmt - Transfere o Objeto para o PreparedStatement.
     * @param connection Conexão com BD
     * @param memberPhotoSave MemberPhoto a ser armazenado
     * @param statement PreparedStatement contendo SQL
     * @throws java.sql.SQLException
     * @param memberOwner Member owner
     */
    private static void obj2stmt(MemberPhoto memberPhotoSave, member.Member memberOwner, java.sql.PreparedStatement statement) throws java.sql.SQLException {
        statement.setInt(1, memberOwner.getId());
        statement.setDate(2, new java.sql.Date(memberPhotoSave.getWhen().getTime()));
        statement.setBlob(3, memberPhotoSave.getPhoto("PNG"));
    }

    /** insert - Este método insere no BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param memberPhotoInsert MemberPhoto a ser inserido
     * @param memberOwner Member owner
     * @throws java.sql.SQLException
     */
    public static void insert(java.sql.Connection connection, MemberPhoto memberPhotoInsert, member.Member memberOwner) throws java.sql.SQLException {
        String sql = "INSERT INTO MemberPhoto (memberOwner,when,photo) "
                   + "VALUES (?,?,?)";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        obj2stmt(memberPhotoInsert, memberOwner, statement);
        statement.executeUpdate();
        statement.close();
        sql = "SELECT IDENTITY_VAL_LOCAL() FROM MemberPhoto";
        statement = connection.prepareStatement(sql);
        java.sql.ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            memberPhotoInsert.setId(resultSet.getInt(1));
        }
        statement.close();
    }

    /** update - Este método atualiza no BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param memberPhotoUpdate MemberPhoto a ser atualizado
     * @param memberOwner Member owner
     * @throws java.sql.SQLException
     */
    public static void update(java.sql.Connection connection, MemberPhoto memberPhotoUpdate, member.Member memberOwner) throws java.sql.SQLException {
        String sql = "UPDATE MemberPhoto SET "
                   + "memberOwner = ?,"
                   + "when = ?,"
                   + "photo = ? "
                   + "WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        obj2stmt(memberPhotoUpdate, memberOwner, statement);
        statement.setInt(4, memberPhotoUpdate.getId());
        statement.executeUpdate();
        statement.close();
    }

    /** delete - Este método apaga do BD o objeto passado como parâmetro.
     * @param connection Conexão com BD
     * @param memberPhotoDelete MemberPhoto a ser apagado
     * @throws java.sql.SQLException
     */
    public static void delete(java.sql.Connection connection, MemberPhoto memberPhotoDelete) throws java.sql.SQLException {
        String sql = "DELETE FROM MemberPhoto WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, memberPhotoDelete.getId());
        statement.executeUpdate();
        statement.close();
    }

    //*****************************************
    //QUERY private
    //*****************************************

    /**
     * rs2obj - Transfere do ResultSet da Query SQL para um novo objeto
     * @param connection
     * @param resultSet to parse
     * @return novo objeto
     * @throws java.sql.SQLException 
     */
    private static MemberPhoto rs2obj(java.sql.Connection connection, java.sql.ResultSet resultSet) throws java.sql.SQLException {
        MemberPhoto memberPhotoLoad = new MemberPhoto();
        memberPhotoLoad.setId(resultSet.getInt("id"));
        memberPhotoLoad.setWhen(resultSet.getDate("when"));
        try {
            memberPhotoLoad.setPhoto(new javax.swing.ImageIcon(javax.imageio.ImageIO.read(resultSet.getBlob("photo").getBinaryStream())));
        } catch (java.io.IOException e) {
            memberPhotoLoad.setPhoto(new javax.swing.ImageIcon());
        } catch (NullPointerException e) {
            memberPhotoLoad.setPhoto(new javax.swing.ImageIcon());
        }
        return memberPhotoLoad;
    }

    /** load - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param condition Condição WHERE
     * @return objeto MemberPhoto || null caso não encontrar
     * @throws java.sql.SQLException
     */
    private static MemberPhoto load(java.sql.Connection connection, String condition) throws java.sql.SQLException {
        if(!condition.isEmpty()){
            String sql = "SELECT id,when,photo "
                       + "FROM MemberPhoto "
                       + "WHERE "+condition;
            java.sql.PreparedStatement statement = connection.prepareStatement(sql);
            java.sql.ResultSet resultSet = statement.executeQuery();
            MemberPhoto memberPhotoLoad;
            if (resultSet.next()) {
                memberPhotoLoad = rs2obj(connection, resultSet);
            } else {
                memberPhotoLoad = null;
            }
            statement.close();
            return memberPhotoLoad;
        } else {
            return null;
        }
    }

    /** loadList - Carrega lista de objetos MemberPhoto
     * @param connection Conexão com BD
     * @param condition Condição WHERE
     * @return List contendo a tabela
     */
    private static java.util.List<MemberPhoto> loadList(java.sql.Connection connection, String condition) {
        java.util.List<MemberPhoto> list = new java.util.ArrayList<MemberPhoto>();
        try {
            String sql = "SELECT id,when,photo "
                       + "FROM MemberPhoto "
                       + (condition.isEmpty()?"":"WHERE "+condition);
            java.sql.PreparedStatement statement = connection.prepareStatement(sql);
            java.sql.ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                MemberPhoto memberPhotoLoad = rs2obj(connection, resultSet);
                list.add(memberPhotoLoad);
            }
            statement.close();
        } catch (java.sql.SQLException sqlex) {
            System.out.println("Falha na leitura do banco de dados !\n"+sqlex.getMessage());
        }
        return list;
    }

    /** loadView - Carrega visão de atributos de objetos MemberPhoto
     * @param connection Conexão com BD
     * @param attributesList Atributos listados
     * @param condition condição WHERE
     * @param order Ordem da lista
     * @return lista de atributo
     */
    private static java.util.List loadView(java.sql.Connection connection, String attributesList, String condition, String order) {
        String sql = "SELECT " + attributesList + " "
                   + "FROM MemberPhoto "
                   + (condition.isEmpty() ? "" : "WHERE " + condition)
                   + (order.isEmpty() ? "" : "ORDER BY " + order);
        return execQueryF(connection, sql);
    }

    //*****************************************
    //QUERY public
    //*****************************************

    //*****************************************
    //LOAD Object BY
    //*****************************************

    /** loadById - Este método carrega o objeto com o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de MemberPhoto
     * @return objeto MemberPhoto || null caso não encontrar
     * @throws java.sql.SQLException
     */
    public static MemberPhoto loadById(java.sql.Connection connection, Integer id) throws java.sql.SQLException {
        return load(connection, "id = "+id);
    }

    //*****************************************
    //EXISTS Object BY
    //*****************************************

    /** existsById - Este método verifica a existência de um objeto pelo o seu identificador
     * @param connection Conexão com BD
     * @param id campo identificador de MemberPhoto
     * @return true caso exista || false caso não exista
     */
    public static Boolean existsById(java.sql.Connection connection, Integer id) {
        java.util.List<MemberPhoto> l = loadList(connection, "id="+id);
        return !l.isEmpty();
    }

    //*****************************************
    //LOAD Attribute List
    //*****************************************

    /** loadIdList - Carrega lista de id de objetos MemberPhoto
     * @param connection Conexão com BD
     * @return List contendo Id
     */
    public static java.util.List<String> loadIdList(java.sql.Connection connection) {
        return loadView(connection, "id", "", "id");
    }

    //*****************************************
    //LOAD Object List
    //*****************************************

    /** loadList - Retorna Lista de objetos MemberPhoto por Member
     * @param connection Conexão com BD
     * @param memberOwner Member
     * @return List contendo os objetos
     */
    public static java.util.List<MemberPhoto> loadList(java.sql.Connection connection, member.Member memberOwner) {
        return loadList(connection, "memberOwner = " + memberOwner.getId());
    }

    //*****************************************
    //LOAD Object View
    //*****************************************

}
