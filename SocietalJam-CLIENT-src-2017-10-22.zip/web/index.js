var map;
var menu;
var marker;

$(document).ready(function () {
    //$("#pWait").html("Carregando...");
    map = new Map();
    menu = new Menu();
    marker = new Marker();
    
    /* Inicio */
    menu.formConfig();
    $("#pMarker").load("marker/marker.html");
    
    $("#pMarker").hide();
    $("#pSearch").hide();
    $("#pMenu").hide();
    
    $("#bGoToMarker").hide();

    $("#bMarker").hide();
    map.locate();
});

