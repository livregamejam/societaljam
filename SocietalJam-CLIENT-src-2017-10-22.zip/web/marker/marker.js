class Marker {
    constructor() {
        this.urbanTroubleList = Marker.getUrbanTroubleList();
    }

    formConfig() {
        $("#bMarkerCancel").on("click", () => this.bMarkerCancelClick());
        $("#bMarkerUrbanTrouble").on("click", () => this.bMarkerUrbanTroubleClick());

        for (let i = 0; i < 14; i++) {
            $("#markerUrbanTroubleOptions").append("<button class=\"markerButton\" id=\"markerUrbanTroubleOptions" + (i + 1) + "\">" + this.urbanTroubleList[i] + "</button>");
            $("#markerUrbanTroubleOptions" + (i + 1)).on("click", (evt) => this.bMarkerUrbanTroubleOptionClick(evt));
        }

        $("#bMarkerDataCancel").on("click", () => this.bMarkerDataCancelClick());
        $("#bMarkerFormCancel").on("click", () => this.bMarkerFormCancelClick());
        $("#bMarkerFormConfirm").on("click", () => this.bMarkerFormConfirmClick());
        $("#markerFormDataContent").on("submit", (evt) => this.bMarkerFormSubmit(evt));

        $("#markerUrbanTroubleOptions").hide();
        $("#markerEventOptions").hide();
    }

    initMarkerForm() {
        $("#markerFormType").show();
        $("#markerFormData").hide();
        $("#markerUrbanTroubleOptions").hide();
    }

    saveMarker() {
        var s = 10;
        $.ajax({
            type: "post",
            //url: "MainController",
            url: "http://localhost:8080/societaljam/MainController",
            async: false,
            data: {
                action: "saveMarker",
                type: $("#tMarkerType").val(),
                latitude: $("#tMarkerLat").val(),
                longitude: $("#tMarkerLng").val(),
                title: $("#tMarkerTitle").val(),
                comment: $("#tMarkerComment").val()
            },
            success: function (data) {
                map.map.removeLayer(map.pointedMarker);
                s = data.status;
            }
        });
        return s;
    }

    bMarkerCancelClick() {
        $("#markerUrbanTroubleOptions").hide();
        $("#pMarker").hide();
    }

    bMarkerUrbanTroubleClick() {
        if ($("#markerUrbanTroubleOptions").is(":hidden")) {
            $("#markerUrbanTroubleOptions").show();
        } else {
            $("#markerUrbanTroubleOptions").hide();
        }
    }

    bMarkerUrbanTroubleOptionClick(evt) {
        var idx = parseInt(evt.target.id.toString().replace("markerUrbanTroubleOptions", ""));
        $("#tMarkerLat").val(map.pointedMarker.getLatLng().lat);
        $("#tMarkerLng").val(map.pointedMarker.getLatLng().lng);
        $("#tMarkerType").val(idx);
        $("#tMarkerTypeF").val($("#markerUrbanTroubleOptions" + idx).text() + " : " + map.pointedMarker.getLatLng().lat + ", " + map.pointedMarker.getLatLng().lng);
        $("#markerFormType").hide();
        $("#markerFormData").show();
    }

    bMarkerDataCancelClick() {
        $("#markerFormData").hide();
        $("#markerFormType").show();
    }

    bMarkerFormCancelClick() {
        $("#markerUrbanTroubleOptions").hide();
        $("#pMarker").hide();
    }

    bMarkerFormConfirmClick() {
        if ($("#tMarkerTitle").val() !== "" && $("#tMarkerComment").val() !== "") {
            $("#markerFormDataContent").submit();
        }
    }

    bMarkerFormSubmit(evt) {
        evt.preventDefault();
        //$("#pWait").show();
        let status = this.saveMarker();
        if (status === 0) {
            $("#pMarker").hide();
            map.refreshMarkers();
        } else {
            alert(status);
        }
        //$("#pWait").hide();
    }
    static getUrbanTroubleList() {
        var list;
        $.ajax({
            type: "get",
            //url: "MainController",
            url: "http://localhost:8080/societaljam/MainController",
            async: false,
            data: {
                action: "getUrbanTroubleList"
            },
            success: function (data) {
                list = data.urbanTroubleList;
            }
        });
        return list;
    }

    static getMarker(id) {
        var marker;
        $.ajax({
            type: "get",
            //url: "MainController",
            url: "http://localhost:8080/societaljam/MainController",
            async: false,
            data: {
                action: "getMarker",
                id: "" + id
            },
            success: (data) => {
                if (data.status >= 0) {
                    marker = data.marker;
                } else {
                    alert("Erro ao carregar marcadores: " + data.status);
                }
            },
            error: (jqXHR, textStatus, errorThrown) => {
                alert("Erro ao carregar marcador do servidor!! \n" + errorThrown + "\n" + textStatus);
            }
        });
        return marker;
    }

    static getNearMarkers(lat, lng) {
        var markers;
        $.ajax({
            type: "get",
            //url: "MainController",
            url: "http://localhost:8080/societaljam/MainController",
            async: false,
            data: {
                action: "getNearMarkers",
                latitude: "" + lat,
                longitude: "" + lng
            },
            success: (data) => {
                if (data.status >= 0) {
                    markers = data.markers;
                } else {
                    alert("Erro ao carregar marcadores: " + data.status);
                }
            },
            error: (jqXHR, textStatus, errorThrown) => {
                alert("Erro ao carregar marcadores do servidor!! \n" + errorThrown + "\n" + textStatus);
            }
        });
        return markers;
    }

}
