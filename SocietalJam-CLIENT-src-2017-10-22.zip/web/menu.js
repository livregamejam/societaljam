class Menu {
    constructor() {
    }

    formConfig() {
        $("#bMenu").on("click", () => this.bMenuClick() );
        $("#bMarker").on("click", () => this.bMarkerClick() );
        $("#bLocate").on("click", () => this.bLocateClick() );
        $("#bGoToMarker").on("click", () => this.bGoToMarkerClick() );
    }

    bLocateClick() {
        $("#bMarker").hide();
        map.locate({setView: true, maxZoom: 17});
    }

    bGoToMarkerClick() {
        $("#bMarker").hide();
        $("#pMarker").hide();
        $("#bGoToMarker").hide();
        map.goToPointedLocation();
    }

    bMenuClick() {
        if ($("#pMenu").is(":hidden")) {
            $("#pMenu").show();
        } else {
            $("#pMenu").hide();
        }
    }

    bMarkerClick() {
        if ($("#pMarker").is(":hidden")) {
            marker.initMarkerForm();
            $("#pMarker").show();
        } else {
            $("#pMarker").hide();
        }
    }
}
