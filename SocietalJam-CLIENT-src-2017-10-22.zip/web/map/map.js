class Map {
    constructor() {
        /* Icons */
        this.iconWalk = L.icon({iconUrl: "icons/player/Walk.png", iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -16]});
        this.iconPointed = L.icon({iconUrl: "icons/map/Pin.png", iconSize: [32, 32], iconAnchor: [4, 27], popupAnchor: [16, -16]});
        this.iconMarker = L.icon({iconUrl: "icons/map/Hand-Property.png", iconSize: [32, 32], iconAnchor: [4, 27], popupAnchor: [16, -16]});
        this.icons = [
       /*0*/L.icon({iconUrl: "icons/map/Hand-Property.png", iconSize: [32, 32], iconAnchor: [4, 27], popupAnchor: [16, -16]}),
            L.icon({iconUrl: "icons/map/urbantrouble/Roadworks.png", iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -16]}),
            L.icon({iconUrl: "icons/map/urbantrouble/Lightbulb-Delete.png", iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -16]}),
            L.icon({iconUrl: "icons/map/urbantrouble/Medal-Gold-Delete.png", iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -16]}),
       /*5*/L.icon({iconUrl: "icons/map/urbantrouble/Set-Security-Question.png", iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -16]}),
            L.icon({iconUrl: "icons/map/urbantrouble/Soil-Layers.png", iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -16]}),
            L.icon({iconUrl: "icons/map/urbantrouble/Draw-Convolve.png", iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -16]}),
            L.icon({iconUrl: "icons/map/urbantrouble/Lightning-Delete.png", iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -16]})
            //L.icon({iconUrl: "icons/map/urbantrouble/.png", iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -16]}),
        ];

        /* Attributes */
        this.map = L.map("main", {zoomControl: false});
        this.currentMarker = L.marker(null, {icon: this.iconWalk});
        this.pointedMarker = L.marker(null, {icon: this.iconPointed, draggable: true});
        this.updatePointedPosition = true;
        this.nearMarkers = null;
        this.markers = new L.LayerGroup();
        this.markers.addTo(this.map);

        /* Map Config */
        this.map.attributionControl.setPrefix("");
        L.tileLayer("http://{s}.tile.osm.org/{z}/{x}/{y}.png", {
            maxZoom: 19, minZoom: 16,
            attribution: "&copy;<a href='http://osm.org/copyright'>OpenStreetMap</a> contributors"
        }).addTo(this.map);
        /*L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFyY29zbW9yaXNlIiwiYSI6ImNpeW16eHM0cTAwMG4zdXBmd3g4dDV5angifQ.GKue8ncxH_9Vd5iU2o6SBQ",
         {maxZoom: 19, minZoom: 16, id: "mapbox.streets"}
         ).addTo(this.map);*/

        this.map.on("locationfound", (evt) => this.onMapLocationFound(evt));

        this.map.on("locationerror", (evt) => this.onMapLocationError(evt));

        this.map.on("contextmenu", (evt) => this.onMapContextMenu(evt));

        this.map.on("click", (evt) => this.onMapClick(evt));

        this.pointedMarker.on("click", (evt) => this.onPointedMarkerClick(evt));

        this.pointedMarker.on("dragend", (evt) => this.onPointedMarkerDragEnd(evt));

    }

    refreshMarkers() {
        //$("#pWait").show();
        this.markers.clearLayers();
        this.nearMarkers = Marker.getNearMarkers(this.currentMarker.getLatLng().lat,this.currentMarker.getLatLng().lng);
        for(let i = 0; i< this.nearMarkers.length; i++) {
            //var newmarker = L.marker(L.latLng(Number(this.nearMarkers[i].latitude), Number(this.nearMarkers[i].longitude)), {icon: this.iconMarker});
            var newmarker = L.marker(L.latLng(Number(this.nearMarkers[i].latitude), Number(this.nearMarkers[i].longitude)), {icon: this.icons[this.nearMarkers[i].type>=this.icons.length?0:this.nearMarkers[i].type]});
            newmarker.on("click", (evt) => this.onMarkerClick(evt));
            this.markers.addLayer(newmarker);
        }
        //$("#pWait").hide();
    }
    
    locate() {
        this.map.locate({setView: true, maxZoom: 17});
    }

    goToPointedLocation() {
        //alert(this.pointedMarker.valueOf());
        this.map.removeLayer(this.pointedMarker);
        this.currentMarker.setLatLng(this.pointedMarker.getLatLng());
        this.currentMarker.bindPopup(Map.getInformationFromLatLng(this.pointedMarker.getLatLng().lat, this.pointedMarker.getLatLng().lng));
        this.map.panTo(this.currentMarker.getLatLng());
        this.refreshMarkers();
    }

    onMarkerClick(evt) {
        let i = this.markers.getLayers().indexOf(evt.target);
        let id = this.nearMarkers[i].id;
        let marker = Marker.getMarker(id);
        alert(JSON.stringify(marker));
    }

    onMapLocationFound(evt) {
        //alert(evt.latlng);
        this.currentMarker.setLatLng(evt.latlng);
        this.currentMarker.bindPopup(Map.getInformationFromLatLng(evt.latlng.lat, evt.latlng.lng));
        this.currentMarker.addTo(this.map);
        this.refreshMarkers();
        $("#pMarker").hide();
        $("#bMarker").hide();
        $("#bGoToMarker").hide();
        $("#pWait").html("");
    }

    onMapLocationError(evt) {
        alert(evt.message);
    }

    onMapContextMenu(evt) {
        this.pointedMarker.closePopup();
        this.pointedMarker.setLatLng(evt.latlng);
        this.pointedMarker.addTo(this.map);
        this.updatePointedPosition = true;
        /*
         marker.bindPopup("Loading...",{minWidth : 140});
         var popup = marker.getPopup();
         var url = "forms/pointedMarkerOptions.html";
         $.get(url).done(function (page) {
         popup.setContent(page);
         popup.update();
         });
         marker.openPopup();
         */
        $("#pMarker").hide();
        $("#bMarker").show();
        $("#bGoToMarker").show();
    }

    onMapClick(evt) {
        this.map.removeLayer(this.pointedMarker);
        this.updatePointedPosition = true;
        $("#pMarker").hide();
        $("#bMarker").hide();
        $("#bGoToMarker").hide();
    }

    onPointedMarkerClick(evt) {
        //$("#pWait").show();
        if (this.updatePointedPosition) {
            this.pointedMarker.bindPopup(Map.getInformationFromLatLng(evt.latlng.lat, evt.latlng.lng));
            this.updatePointedPosition = false;
        }
        //this.pointedMarker.bindPopup("Location: "+evt.latlng.lat+", "+evt.latlng.lng);
//        if (this.lastPointedPosition.lat !== evt.latlng.lat || this.lastPointedPosition.lng !== evt.latlng.lng) {
//            this.pointedMarker.bindPopup(Map.getInformationFromLatLng(evt.latlng.lat, evt.latlng.lng));
//        }
//        this.lastPointedPosition = evt.latlng;
//        this.pointedMarker.openPopup();
//        var popup = marker.getPopup();
//        var url = "forms/pointedMarkerOptions.html";
//        $.get(url).done(function (page) {
//            popup.setContent(page);
//            popup.update();
//        });
    }

    onPointedMarkerDragEnd(evt) {
        this.updatePointedPosition = true;
    }

    static getInformationFromLatLng(lat, lng) {
        let result = "";
        //$("#pWait").html("Aguarde");
        $.ajax({
            type: "get",
            //url: "https://maps.googleapis.com/maps/api/geocode/json?latlng=" + lat + "," + lng + "&sensor=false",
            url: "https://nominatim.openstreetmap.org/reverse?format=json&lat=" + lat + "&lon=" + lng + "",
            async: false,
            beforeSend: () => {
                //$("#pWait").show();
            },
            success: (data) => {
                //result = data.results[0].formatted_address;
                result += "<b>Local:</b><br/>";
                result += data.display_name + "<br/><br/>";
                result += "<b>" + "Coordenadas:</b><br/>" + lat + ", " + lng;
            },
            complete: () => {
               //$("#pWait").hide();
               //$("#pWait").html("");
            }
        });
        return result;
    }
    static getLatLngFromInformation(information) {
        let result = "";
        $.ajax({
            type: "get",
            url: "https://nominatim.openstreetmap.org/search?q=" + information + "&format=json",
            async: false,
            beforeSend: function () {
                //$("#pWait").show();
            },
            success: function (data) {
                //result = data.results[0].formatted_address;
                //result = JSON.stringify(data);
                result = {'lat': data[0].lat, 'lgn': data[0].lon};
            },
            complete: function () {
                //$("#pWait").hide();
            }
        });
        return result;
    }

}
